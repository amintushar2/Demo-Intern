package rz.hrsoftbd.ehospital.aboutehospital;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AboutEHospitalViewModel extends ViewModel {
    // TODO: Implement the ViewModel

private MutableLiveData<String> mtext;

public AboutEHospitalViewModel(){
    mtext = new MutableLiveData<>();
    mtext.setValue("This Is HomeFragment");
}

    public LiveData<String> getText() {
        return mtext;
    }
}