package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Kolema extends AppCompatActivity {
    private  Button toyeba,mufassal,shahadat, tamjid , tawhid, tayeba,mujmal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kolema);
        toyeba = findViewById(R.id.ktaiba);
        shahadat = findViewById(R.id.kshahadat);
        mufassal = findViewById(R.id.kmufassal);
        tamjid = findViewById(R.id.ktamjid);
        tawhid = findViewById(R.id.dtawhid);
        mujmal = findViewById(R.id.mujmal);


        toyeba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Tayeba.class);
                startActivity(intent);
                finish();
            }
        });
        shahadat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Shahadat.class);
                startActivity(intent);
            }
        });
        mujmal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Mujmal.class);
                startActivity(intent);
            }
        });
        tamjid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Tamjid.class);
                startActivity(intent);
            }
        });
        tawhid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Tawhid.class);
                startActivity(intent);
            }
        });
        mufassal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kolema.this, Mufassal.class);
                startActivity(intent);
            }
        });


    }

    public void onBackPressed() {
        Intent startMain = new Intent(this,MainActivity.class);
        startActivity(startMain);
        finish();
    }
}