package com.example.demoapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

Button menuBtn, kolemaBtn, durudBtn, chotosuraBtn, duaBtn , othersBTN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       TypeFace.overrideFont(this,"SERIF","solaiman_lipi.ttf");
        setContentView(R.layout.activity_main);
            menuBtn = findViewById( R.id.button);
            kolemaBtn = findViewById(R.id.btn1);
            durudBtn=findViewById(R.id.durud);
            chotosuraBtn=findViewById(R.id.chotosura);
            duaBtn=findViewById(R.id.btn4);
            othersBTN=findViewById(R.id.btn5);
        kolemaBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent =new Intent(MainActivity.this,Kolema.class);
        startActivity(intent);

    }
});


//        Typeface font = Typeface.createFromAsset(getAssets(), "solaiman_lipi.ttf");
//        kolemaBtn.setTypeface(font);
//        durudBtn.setTypeface(font);
//        chotosuraBtn.setTypeface(font);
//        duaBtn.setTypeface(font);
//        othersBTN.setTypeface(font);


        durudBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,Durud.class);
                startActivity(intent);

            }
        });
        chotosuraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,ChotoSura.class);
                startActivity(intent);

            }
        });
        duaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,Dowa.class);
                startActivity(intent);

            }
        });
        othersBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,Extra.class);
                startActivity(intent);

            }
        });

menuBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        PopupMenu menu = new PopupMenu(MainActivity.this,menuBtn);
        menu.getMenuInflater().inflate(R.menu.menu1,menu.getMenu());

        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()){
                    case R.id.status:
                        Toast.makeText(MainActivity.this, "Status", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.setting:
                        Toast.makeText(MainActivity.this, "Setting", Toast.LENGTH_SHORT).show();
                        return true;
                    default:
                        return false;
                }
            }
        });
        menu.show();
    }
});


        }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                MainActivity.this);

        alertDialogBuilder.setTitle("Are You Sure For Exit ??");
        alertDialogBuilder
                .setMessage("Click yes to exit!")
                .setCancelable(false)
                .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {

                        MainActivity.this.finish();

                    }
                })
                .setNegativeButton("No",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {

                        dialog.cancel();
                    }
                });


        AlertDialog alertDialog = alertDialogBuilder.create();


        alertDialog.show();
    }
    }

