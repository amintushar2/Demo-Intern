package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class Tayeba extends AppCompatActivity {
    private ImageButton pausebtn, playbtn;
    private MediaPlayer mPlayer;
    private TextView startTime, songTime;
    private SeekBar seekBar;
    private static int oTime =0, sTime =0, eTime =0, fTime = 5000, bTime = 5000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tayeba);
        playbtn=findViewById(R.id.btnPlay);
        pausebtn=findViewById(R.id.btnPause);
        startTime=findViewById(R.id.txtStartTime);
        songTime=findViewById(R.id.txtSongTime);
        seekBar = findViewById(R.id.sBar);
        Handler handler= new  Handler();



        playbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPlayer = MediaPlayer.create(Tayeba.this,R.raw.kalima_tayeba);
                mPlayer.start();
                eTime=mPlayer.getDuration();
                sTime= mPlayer.getCurrentPosition();
                if (oTime==0){
                    seekBar.setMax(eTime);
                    oTime=1;
                }

//                songTime.setText(String.format("%d min, %d sec", TimeUnit.MILLISECONDS.toMinutes(eTime), TimeUnit.MILLISECONDS.toSeconds(eTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes(eTime))) );
//                startTime.setText(String.format("%d min, %d sec", TimeUnit.MILLISECONDS.toMinutes(sTime),
//                        TimeUnit.MILLISECONDS.toSeconds(sTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes(sTime))) );

                seekBar.setProgress(sTime);
                pausebtn.setEnabled(true);
                playbtn.setEnabled(false);
                pausebtn.setVisibility(View.VISIBLE);
                playbtn.setVisibility(View.INVISIBLE);
            }
        });
            pausebtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPlayer.pause();
                    pausebtn.setEnabled(false);
                    playbtn.setEnabled(true);
                    pausebtn.setVisibility(View.INVISIBLE);
                    playbtn.setVisibility(View.VISIBLE);
                }
            });

    }
    public void onBackPressed() {
        Intent startMain = new Intent(this,Kolema.class);
        startActivity(startMain);
        finish();
    }
}