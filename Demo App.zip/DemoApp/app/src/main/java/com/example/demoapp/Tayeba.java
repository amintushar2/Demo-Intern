package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Tayeba extends AppCompatActivity {
    private ImageButton pausebtn, playbtn;
    private MediaPlayer mPlayer;
    private TextView startTime, songTime;
    private SeekBar seekBar;
    private Handler handler;
    private static int oTime =0, sTime =0, eTime =0, fTime = 5000, bTime = 5000;
    Runnable target;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tayeba);
        playbtn=findViewById(R.id.btnPlay);
        pausebtn=findViewById(R.id.btnPause);
        startTime=findViewById(R.id.txtStartTime);
        songTime=findViewById(R.id.txtSongTime);
        seekBar = findViewById(R.id.sBar);
        handler=new Handler();




        playbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int oTime =0, sTime =0, eTime =0, fTime = 5000, bTime = 5000;
                mPlayer = MediaPlayer.create(Tayeba.this,R.raw.kalima_tayeba);
                mPlayer.start();
                eTime = mPlayer.getDuration();
                sTime = mPlayer.getCurrentPosition();
                if(oTime == 0){
                    seekBar.setMax(eTime);
                    oTime =1;
                }
                songTime.setText(String.format("%d min: %d sec", TimeUnit.MILLISECONDS.toMinutes(eTime),
                        TimeUnit.MILLISECONDS.toSeconds(eTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes(eTime))) );
                startTime.setText(String.format("%d min: %d sec", TimeUnit.MILLISECONDS.toMinutes(sTime),
                        TimeUnit.MILLISECONDS.toSeconds(sTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes(sTime))) );
                seekBar.setProgress(sTime);
                seekBar.postDelayed(UpdateSongTime, 100);
                pausebtn.setEnabled(true);
                playbtn.setEnabled(false);
                pausebtn.setVisibility(View.VISIBLE);
                playbtn.setVisibility(View.INVISIBLE);
                seekBarListener();

            }
        });

            pausebtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPlayer.pause();
                    pausebtn.setEnabled(false);
                    playbtn.setEnabled(true);
                    pausebtn.setVisibility(View.INVISIBLE);
                    playbtn.setVisibility(View.VISIBLE);

                }
            });

    }

    private void seekBarListener() {


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                try {
                    if (mPlayer!=null && mPlayer.isPlaying() && fromUser){
                        mPlayer.seekTo(mPlayer.getCurrentPosition());

                    }else if (mPlayer!=null && !mPlayer.isPlaying()){
                        Tayeba.this.seekBar.setProgress(0);
                        startTime.setText("0 min: 0 sec");
                        mPlayer.reset();
                        pausebtn.setEnabled(false);
                        playbtn.setEnabled(true);
                        pausebtn.setVisibility(View.INVISIBLE);
                        playbtn.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mPlayer != null && mPlayer.isPlaying()) {
                    mPlayer.seekTo(seekBar.getProgress());
                }
            }
        });
    }

    public void onBackPressed() {
          if (mPlayer!=null&& mPlayer.isPlaying()){
              try {

                  mPlayer.stop();
                  mPlayer.reset();

              } catch (IllegalStateException e) {
                  e.printStackTrace();
              }


              Intent startMain = new Intent(this,Kolema.class);
              startMain.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
              startMain.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
              startMain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
              startActivity(startMain);
              finish();
          }
        else {
              Intent startMain = new Intent(this,Kolema.class);
              startActivity(startMain);
              finish();
          }
//      Intent startMain = new Intent(this,Kolema.class);
//      startActivity(startMain);
//      finish();

    }


private Runnable UpdateSongTime = new Runnable() {
    @Override
    public void run() {

            sTime = mPlayer.getCurrentPosition();
            startTime.setText(String.format("%d min: %d sec", TimeUnit.MILLISECONDS.toMinutes(sTime),
                   TimeUnit.MILLISECONDS.toSeconds(sTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(sTime))));
            seekBar.setProgress(sTime);
            handler.postDelayed(this, 100);

    }
};


}