package com.example.doctorappointmentapp.pojo;

public class ChipItem {
    private String itemName;

    public ChipItem() {
    }

    public ChipItem(String itemName) {
        this.itemName = itemName;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
}
