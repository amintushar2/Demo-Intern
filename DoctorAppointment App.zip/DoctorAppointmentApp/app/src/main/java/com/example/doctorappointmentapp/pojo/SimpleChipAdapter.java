package com.example.doctorappointmentapp.pojo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.doctorappointmentapp.R;

import java.util.ArrayList;
import java.util.List;

public class SimpleChipAdapter extends ArrayAdapter<ChipItem> {
        private List<ChipItem>chipListFull;

    public SimpleChipAdapter(@NonNull Context context, @NonNull List<ChipItem> chipList) {
        super(context, 0, chipList);
            chipListFull= new ArrayList<>(chipList);
    }

    @NonNull
    @Override
    public Filter getFilter() {
        return chipFilter;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.sampleautocomplete, parent, false);
        }
        TextView textView = convertView.findViewById(R.id.label);

        ChipItem chipItem =getItem(position);
        if (chipItem != null){
            textView.setText(chipItem.getItemName());
        }

        return convertView;
    }

    private Filter chipFilter= new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<ChipItem>sugesstion = new ArrayList<>();

                if(constraint == null|| constraint.length()==0){
                    sugesstion.addAll(chipListFull);

                }else {}
                String filterpattern = constraint.toString().toLowerCase().trim();
                for (ChipItem item: chipListFull){
                    if (item.getItemName().toLowerCase().contains(filterpattern)) {
                    }
                    }
                results.values=sugesstion;
                results.count=sugesstion.size();

                return results;
                }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {

                List<ChipItem>filterd = (ArrayList<ChipItem>) results.values;

                if(results != null && results.count > 0 ){
                    clear();
                    for (ChipItem item : filterd){
                        addAll(item);
                        notifyDataSetChanged();
                    }
                }

            }

            @Override
            public CharSequence convertResultToString(Object resultValue) {
                return ((ChipItem)resultValue).getItemName();
            }
        };

}
