package com.example.doctorappointmentapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.button.MaterialButton;

public class PatmentActivity extends AppCompatActivity {
    MaterialButton button;
    Dialog dialog;
    Button closebtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patment);

        getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'>পেমেন্ট</font>")));

//        dialog = new Dialog(this);
//        dialog.setContentView(R.layout.popup);



        button = findViewById(R.id.catBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              dialogShow();
            }

            private void dialogShow() {

                final Dialog dialog = new Dialog(PatmentActivity.this);
                dialog.setContentView(R.layout.popup);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                Button dialogButton = (Button) dialog.findViewById(R.id.read_btn);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        Intent intent = new Intent(PatmentActivity.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });

                dialog.show();
            }
        });
//
//                AlertDialog.Builder builder = new AlertDialog.Builder(PatmentActivity.this);
//                ViewGroup viewGroup = findViewById(android.R.id.content);
//                View dialogView = LayoutInflater.from(v.getContext()).inflate(R.layout.popup, viewGroup, false);
//                builder.setView(dialogView);
//                AlertDialog alertDialog = builder.create();
//                alertDialog.show();

            }




    }


