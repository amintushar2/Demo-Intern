package com.example.doctorappointmentapp.pojo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctorappointmentapp.DoctorList;
import com.example.doctorappointmentapp.R;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.DocViewHolder> {

        private Context context;
        private List<MyDataSet>docList;

    public MyAdapter(Context context, List<MyDataSet> docList) {
        this.context = context;
        this.docList = docList;
    }

    @NonNull
    @Override
    public DocViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.single_row_doclist, parent, false);
        return new DocViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DocViewHolder docViewHolder, int position) {
                docViewHolder.docPic.setImageResource(docList.get(position).getDocPicId());
                docViewHolder.docName.setText(docList.get(position).docName);
                docViewHolder.docTitle.setText(docList.get(position).docTitle);
                docViewHolder.hospitalName.setText(docList.get(position).hospitalName);
                docViewHolder.visitTime.setText(docList.get(position).docHours);
    }

    @Override
    public int getItemCount() {
        return docList.size();
    }

    class  DocViewHolder extends RecyclerView.ViewHolder{
        TextView docName,docTitle,hospitalName,visitTime;
        ImageView docPic;
        public DocViewHolder(@NonNull View itemView) {
            super(itemView);
            docName = itemView.findViewById(R.id.docName);
            docTitle = itemView.findViewById(R.id.docTitle);
            hospitalName = itemView.findViewById(R.id.hospitalName);
            visitTime = itemView.findViewById(R.id.timeVisit);
            docPic =itemView.findViewById(R.id.docPIC);
        }
    }
}
