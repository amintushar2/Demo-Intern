package com.example.doctorappointmentapp.pojo;

public class MyDataList {

}
