package com.example.doctorappointmentapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;

public class DoctorProfile extends AppCompatActivity {
    MaterialButtonToggleGroup toggleGroup;
    MaterialButton dfBtnNxt , dfBtnPrev;
    DatePickerDialog.OnDateSetListener onDateSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'>ডাক্তারের বিবরনী </font>")));
        final TextView datePicker = findViewById(R.id.datePicker);


        Calendar calendar = Calendar.getInstance();
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        final int month =calendar.get(Calendar.MONTH);
        final int year = calendar.get(Calendar.YEAR);

        datePicker.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v) {
   DatePickerDialog datePickerDialog = new DatePickerDialog(DoctorProfile.this, new DatePickerDialog.OnDateSetListener() {
       @Override
       public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

           SimpleDateFormat dateFormat = new SimpleDateFormat(" dd-MMM-yyyy");
           String dateString = dateFormat.format(dayOfMonth+month+year);
           datePicker.setText(dateString);
       }
   },year,month,day);
datePickerDialog.show();
    }
});

        toggleGroup=findViewById(R.id.materialButtonToggleGroup);
        toggleGroup.setSelectionRequired(true);
        dfBtnNxt= findViewById(R.id.dfBtnNext);
        dfBtnNxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorProfile.this,DoctorPayment.class);
                startActivity(intent);
                finish();
            }
        });
        dfBtnPrev=findViewById(R.id.docLPrevButton);
        dfBtnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(DoctorProfile.this,DoctorList.class);
                startActivity(intent2);
                finish();
            }
        });


        toggleGroup.addOnButtonCheckedListener(new MaterialButtonToggleGroup.OnButtonCheckedListener() {

           @Override
            public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
               MaterialButton mtButton = toggleGroup.findViewById(checkedId);

            }
        });

    }
}