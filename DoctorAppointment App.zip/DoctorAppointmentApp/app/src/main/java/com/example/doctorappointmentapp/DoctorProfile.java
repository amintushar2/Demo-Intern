package com.example.doctorappointmentapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;

public class DoctorProfile extends AppCompatActivity {
    MaterialButtonToggleGroup toggleGroup;
    MaterialButton dfBtnNxt , dfBtnPrev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);
        toggleGroup=findViewById(R.id.materialButtonToggleGroup);
        toggleGroup.setSelectionRequired(true);
        dfBtnNxt= findViewById(R.id.dfBtnNext);
        dfBtnNxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorProfile.this,DoctorPayment.class);
                startActivity(intent);
            }
        });
        dfBtnPrev=findViewById(R.id.docLPrevButton);
        dfBtnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(DoctorProfile.this,DoctorList.class);
                startActivity(intent2);
            }
        });
        toggleGroup.addOnButtonCheckedListener(new MaterialButtonToggleGroup.OnButtonCheckedListener() {


            @Override
            public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
               MaterialButton mtButton = toggleGroup.findViewById(checkedId);

            }
        });

    }
}