package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.doctorappointmentapp.pojo.MyAdapter;
import com.example.doctorappointmentapp.pojo.MyDataSet;

import java.util.ArrayList;
import java.util.List;

public class DoctorList extends AppCompatActivity {
    private Button dctPfNxtbutton, dctPrevtn;
    private RecyclerView recyclerView;
    MyAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);
    getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'>ডাক্তারের তালিকা </font>")));

        recyclerView = findViewById(R.id.doctorListRecycler);
        adapter=new MyAdapter( this,generatedoctorList());
        GridLayoutManager gridLayout =new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(gridLayout);
        recyclerView.setAdapter(adapter);


        dctPfNxtbutton = findViewById(R.id.doctPfNextBtn);
        dctPfNxtbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,DoctorProfile.class);
                startActivity(intent);
                finish();
            }
        });
        dctPrevtn = findViewById(R.id.doctPfPrevvBtn);
        dctPrevtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,MainActivity.class);
                startActivity(intent);
       finish();

            }
        });
    }



    private List<MyDataSet> generatedoctorList(){
        List<MyDataSet>docList = new ArrayList<>();
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","এমবিবিএস, এফসিপিএস(মেডিসিন)","ল্যাবএইড হসপিটাল","সকাল ১০ টা - বিকাল ৪টা"));



        return docList;
    }
}