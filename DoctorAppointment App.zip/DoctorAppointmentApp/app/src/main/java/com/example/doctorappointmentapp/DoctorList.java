package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DoctorList extends AppCompatActivity {
    private Button dctPfNxtbutton, dctPrevtn;
    private LinearLayout lout;
    AppCompatImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);
        lout=findViewById(R.id.lout);
        imageView = findViewById(R.id.profile_id_single_user);
        lout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


             lout.setBackgroundResource(R.drawable.back_rv);
                imageView.setImageResource(R.drawable.ic_slectedstate);
            }
        });

        dctPfNxtbutton = findViewById(R.id.doctPfNextBtn);
        dctPfNxtbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,DoctorProfile.class);
                startActivity(intent);
            }
        });
        dctPfNxtbutton = findViewById(R.id.doctPfPrevvBtn);
        dctPfNxtbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}