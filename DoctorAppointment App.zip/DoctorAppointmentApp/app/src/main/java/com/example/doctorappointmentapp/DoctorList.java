package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.doctorappointmentapp.pojo.MyAdapter;
import com.example.doctorappointmentapp.pojo.MyDataSet;

import java.util.ArrayList;
import java.util.List;

public class DoctorList extends AppCompatActivity {
    private Button dctPfNxtbutton, dctPrevtn;
    private RecyclerView recyclerView;
    MyAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);
//        lout=findViewById(R.id.lout);
        recyclerView = findViewById(R.id.doctorListRecycler);
        adapter=new MyAdapter( this,generatedoctorList());
        GridLayoutManager gridLayout =new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(gridLayout);
        recyclerView.setAdapter(adapter);


//        imageView = findViewById(R.id.docPIC);
//        lout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//             lout.setBackgroundResource(R.drawable.back_rv);
//                imageView.setImageResource(R.drawable.ic_slectedstate);
//            }
//        });

        dctPfNxtbutton = findViewById(R.id.doctPfNextBtn);
        dctPfNxtbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,DoctorProfile.class);
                startActivity(intent);
            }
        });
        dctPfNxtbutton = findViewById(R.id.doctPfPrevvBtn);
        dctPfNxtbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorList.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }



    private List<MyDataSet> generatedoctorList(){
        List<MyDataSet>docList = new ArrayList<>();
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));
        docList.add(new MyDataSet(R.drawable.doc1,"ডাঃ রেজাাউল করিম","MBBS, FCPS","LABAID HOSPITAL","10-3"));




        return docList;
    }
}