package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MultiAutoCompleteTextView;

import com.example.doctorappointmentapp.pojo.ChipItem;
import com.example.doctorappointmentapp.pojo.MyDataSet;
import com.example.doctorappointmentapp.pojo.SimpleChipAdapter;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button nxtBtn;
    List<ChipItem>chipItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'>সমস্যা বিবরনী </font>")));



//        fillChipsView();
//        MultiAutoCompleteTextView simpleMultiAutoCompleteTextView =  findViewById(R.id.multiAutoCompleteTextView);
//        SimpleChipAdapter adapter = new SimpleChipAdapter(this,chipItems);
//        simpleMultiAutoCompleteTextView.setAdapter(adapter);
//        simpleMultiAutoCompleteTextView.setThreshold(1);
//        simpleMultiAutoCompleteTextView.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        nxtBtn=findViewById(R.id.bttnNxtMain);
        nxtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,DoctorList.class);
                startActivity(intent);
                finish();
            }
        });


    }
    private void fillChipsView() {
        chipItems = new ArrayList<>();
        chipItems.add(new ChipItem("Amin"));
        chipItems.add(new ChipItem("Tushar"));
        chipItems.add(new ChipItem("জ্বর"));
        chipItems.add(new ChipItem("জ্বর"));
        chipItems.add(new ChipItem("র্সদি"));
        chipItems.add(new ChipItem("শুকনো কাশ"));
        chipItems.add(new ChipItem("পেটে ব্যাথা"));
        chipItems.add(new ChipItem("ডায়াবেটিকস"));
        chipItems.add(new ChipItem("রক্ত চাপ"));
        chipItems.add(new ChipItem("দাতে ব্যাথা"));


    }

    @Override
    public void onBackPressed() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.popupbackpressed);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        ImageView dialogButton = (ImageView) dialog.findViewById(R.id.close);
        ImageView dialogButton2 = (ImageView) dialog.findViewById(R.id.cancel);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
finishAffinity();            }
        });
        dialogButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();            }
        });
        dialog.show();
    }
}