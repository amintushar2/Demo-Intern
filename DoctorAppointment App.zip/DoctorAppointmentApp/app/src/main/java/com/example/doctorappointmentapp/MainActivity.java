package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button nxtBtn;

    CheckBox checkBox1,checkBox2,checkBox3,checkBox4,checkBox5,checkBox6,checkBox7,checkBox8,checkBox9;

    String[] str = { "জ্বর", "র্সদি","কাশি",
            "পেটে ব্যাথা", "দাত ব্যাথা","ডায়াবেটিকস","শুকনো কাশ"};

//    Context context;
//    CheckBox checkBox = new CheckBox(context);
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'> সমস্যা বিবরনী </font>")));


//        simpleMultiAutoCompleteTextView.setThreshold(1);
//        simpleMultiAutoCompleteTextView.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        nxtBtn=findViewById(R.id.bttnNxtMain);
        nxtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,DoctorList.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.popupbackpressed);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        ImageView dialogButton = (ImageView) dialog.findViewById(R.id.close);
        ImageView dialogButton2 = (ImageView) dialog.findViewById(R.id.cancel);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
finishAffinity();            }
        });
        dialogButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();            }
        });
        dialog.show();
    }
}