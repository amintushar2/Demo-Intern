package com.example.doctorappointmentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class DoctorPayment extends AppCompatActivity {
    MaterialButton button1 , button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_payment);


        getSupportActionBar().setTitle((Html.fromHtml("<font color='#ffffff'>পেমেন্ট ক্যাটাগরি </font>")));


        button1 = findViewById(R.id.doctPayPrevvBtn);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(DoctorPayment.this , DoctorProfile.class);
                startActivity(intent);
                finish();
            }
        });
        button2 = findViewById(R.id.doctpayNextBtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorPayment.this,PatmentActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}